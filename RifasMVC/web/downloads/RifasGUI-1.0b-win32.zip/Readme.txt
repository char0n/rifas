RifasGUI 1.0b
Date January 25 2009

RifasGUI is a desktop RIFAS application independent of RIFAS web application.
RifasGUI searches for files on internet and make their URIs awaillable to you
for further processing.


===================================================
INSTALATION
===================================================

Unpack the RifasGUI.zip archive to empty folder. Instalation is complete.

===================================================
RUNNTIME ENVIROMENT
===================================================

Windows
_______

On Windows run the RifasGUI.exe file to execute the program. You can run
RifasGUI.exe file by double-clicking it. If it doesn't work for some reason
try to double click the RifasGUI.jar file. If this doesn't work either,
try to run it from command line like this:

java -jar RifasGUI.jar

OR...

javaw -jar RifasGUI.jar

Linux
_____

In #bash type:

java -jar RifasGUI.jar

===================================================
LICENSING
===================================================

Please refer to the License.txt file.

===================================================
REQUIREMENTS
===================================================

There are no special requirements for running this program.
To run it you need internet connection and also to have installed
JRE 6 (Java Runtime Enviroment version 6) or higher. For more info refer
to Java download page: http://java.sun.com/javase/downloads/index.jsp