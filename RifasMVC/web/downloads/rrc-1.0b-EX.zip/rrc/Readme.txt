Rifas Remote Checker (RRC) 1.0b EXPERIMENTAL
Date March 9 2009

Rifas Remote Checker later only RRC is a javascript library capable of beeing applied on every html/xhtml webpage. 
RRC is a standalone library with no dependancies. RRC is suitable for every blog/forum/webpage which hosts links
to rapidshare/megaupload... storage engines. RIFAS currently supports only rapidshare.com storage engine. After 
implemented your visitor can check these links for validity and size without leaving your page. Implementation is trivial,
gane for visitors is huge. RRC only support storage engines that RIFAS project generaly supports. Storage engine
is detected automatically by RRC. 


For more information refer to http://rifasproject.org/rrc/docs